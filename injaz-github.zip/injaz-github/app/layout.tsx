import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "إنجاز | أحياء",
  description: "منصة ريان الداود لتعلم الأحياء ومتابعة الطلاب والتواصل مع الأسرة",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "إنجاز", statusBarStyle: "default" },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
    apple: "/icon-192.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl">
      <body className="antialiased">{children}</body>
    </html>
  );
}
