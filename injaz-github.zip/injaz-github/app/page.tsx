import { getChatGPTUser, chatGPTSignInPath } from './chatgpt-auth';
import Injaz from './injaz';
export const dynamic='force-dynamic';
export default async function Page(){const user=await getChatGPTUser();if(!user)return <main className="welcome"><div className="brand-mark">✓</div><h1>إنجاز | أحياء</h1><p>متابعة يومية وتعلّم يجمع الطالب والمعلم والأسرة.</p><a className="primary" href={chatGPTSignInPath('/')} target="_top">تسجيل الدخول بحساب ChatGPT</a><p className="muted">بعد الدخول، أكمل معلوماتك ليراجع المعلم تسجيلك.</p></main>;return <Injaz/>}
