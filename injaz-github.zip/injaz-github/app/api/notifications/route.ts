import {identity,apiError} from '@/lib/injaz-server';
import {pendingFor} from '@/lib/push';
export const dynamic='force-dynamic';
export async function GET(){try{const auth=await identity();return Response.json({items:await pendingFor(auth)},{headers:{'Cache-Control':'no-store'}})}catch(e){return apiError(e)}}
