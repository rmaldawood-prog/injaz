import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '@/app/chatgpt-auth';
export const database=()=>{const binding=(env as any).DB;if(!binding)throw new Error('خدمة الحفظ غير متاحة الآن.');return binding as D1Database};
export const bucket=()=>{const binding=(env as any).BUCKET;if(!binding)throw new Error('خدمة الملفات غير متاحة الآن.');return binding as R2Bucket};
export function fail(message:string,status=400):never{throw Object.assign(new Error(message),{status})}
export async function identity(){const user=await getChatGPTUser();if(!user)fail('سجّل الدخول للمتابعة.',401);const isTeacher=!!(env as any).TEACHER_EMAIL&&user.email.toLowerCase()===(env as any).TEACHER_EMAIL.toLowerCase();const account:any=await database().prepare('SELECT * FROM accounts WHERE id = ?').bind(user.userId).first();return {user,isTeacher,account}}
export function teacher(auth:any){if(!auth.isTeacher)fail('هذه العملية متاحة للمعلم فقط.',403)}
export async function studentsFor(auth:any){if(auth.isTeacher)return (await database().prepare("SELECT * FROM accounts WHERE role = 'student' ORDER BY name").all()).results as any[];if(!auth.account?.approved)return [];if(auth.account.role==='student')return [auth.account];return (await database().prepare("SELECT * FROM accounts WHERE role = 'student' AND approved = 1 AND (json_extract(profile,'$.guardianAccountId')=? OR (COALESCE(json_extract(profile,'$.guardianAccountId'),'')='' AND guardian_email=?)) ORDER BY name").bind(auth.user.userId,auth.user.email.toLowerCase()).all()).results as any[]}
export async function permittedStudent(auth:any,id:string){const students=await studentsFor(auth);const found=students.find(s=>s.id===id);if(!found)fail('لا تملك صلاحية الاطلاع على هذا الطالب.',403);return found}
export function secureWrite(req:Request){const origin=req.headers.get('origin');if(!origin||origin!==new URL(req.url).origin)fail('طلب غير مسموح.',403)}
export function apiError(error:any){console.error('injaz-api',error?.status||500,error?.message);return Response.json({error:error?.status?error.message:'تعذّر إتمام العملية. حاول مرة أخرى.'},{status:error?.status||503,headers:{'Cache-Control':'no-store'}})}
export const now=()=>new Date().toISOString();
export function unpack(row:any){return {...row,data:JSON.parse(row.data||'{}')}}
export const defaultCv={name:'ريان ممدوح الداود',title:'معلم أحياء',school:'ثانوية حائل',about:'',qualifications:'',experience:'',achievements:'',skills:'',links:'',contact:'',photoId:''};
export function safeLink(input:any){if(!input)return '';try{const u=new URL(input);if(u.protocol==='https:')return u.href}catch{}fail('الرابط يجب أن يبدأ بـ https://')}
export async function allowedFile(auth:any,file:any){if(auth.isTeacher||file.owner_id===auth.user.userId)return true;const students=await studentsFor(auth);if(students.some(s=>s.id===file.owner_id))return true;const owner:any=await database().prepare('SELECT role FROM accounts WHERE id = ?').bind(file.owner_id).first();if(owner?.role!=='teacher')return false;return students.some(s=>file.class_name==='*'||file.class_name===s.class_name)}
