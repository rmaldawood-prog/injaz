export const GRADES=['أول ثانوي','ثاني ثانوي','ثالث ثانوي'] as const;
export const SECTIONS=['1','2','3','4','5','6'] as const;
export const arabicNumber=(n:string)=>n.replace(/[0-9]/g,d=>'٠١٢٣٤٥٦٧٨٩'[Number(d)]);
export const classLabel=(grade:string,section:string)=>`${grade} — الشعبة ${arabicNumber(section)}`;
